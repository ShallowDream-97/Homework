import socket
import os
import hashlib
import threading,time
import json

class SessionManege(threading.Thread):
    messageConnTable = {}
    fileConnTable = {}
    videoConnTable = {}
    pairTable = {}
    
    def newSession(self, messageConn, fileConn,videoConn):
        chat_Session = MessageSession(messageConn, fileConn,videoConn,self)
        chat_Session.start()


    def close_messageConn(self,userID):
        self.messageConnTable.pop(userID)
        self.fileConnTable.pop(userID)
        self.videoConnTable.pop(userID)
        self.pairTable.pop(userID)
        print(userID,"连接关闭")
    
class MessageSession(threading.Thread):

    def __init__(self, messageConn, fileConn, videoConn, SessionManege):
        super(MessageSession, self).__init__()
        self.messageConn = messageConn
        self.fileConn = fileConn
        self.videoConn = videoConn
        self.SessionManege = SessionManege

    def pairTest(self,selfID,targetID):
        if selfID in self.SessionManege.messageConnTable:
            self.messageConn.send(json.dumps({
                        'type': 'systemMassage',
                        'info': "用户名重复！"
                    }).encode("utf-8"))
            return
        '''
        连接成功后将连接信息添加到各个字典中
        '''
        self.selfID = selfID
        self.SessionManege.messageConnTable[selfID] = self.messageConn
        self.SessionManege.fileConnTable[selfID] = self.fileConn
        self.SessionManege.videoConnTable[selfID] = self.videoConn
        self.SessionManege.pairTable[selfID] = targetID
        '''
        返回信息
        '''
        if(self.SessionManege.messageConnTable.get(targetID)):
            self.targetmessageConn = self.SessionManege.messageConnTable.get(targetID)
            self.messageConn.send(json.dumps({
                        'type': 'pairTestResult',
                        'success': True,
                    }).encode("utf-8"))
            self.targetmessageConn.send(json.dumps({
                        'type': 'pairTestResult',
                        'success': True,
                    }).encode("utf-8"))
            return True
        else :
            self.messageConn.send(json.dumps({
                        'type': 'pairTestResult',
                        'success': False,
                    }).encode("utf-8"))
            return False

    def msgHandle(self,msg):
        data = json.loads(msg)
        if data['type'] == "Message":  #连接成功后从messageConnTable中获取targetID的messageConn        
            targetmessageConn = self.SessionManege.messageConnTable.get(data['targetID'])
            targetmessageConn.send(json.dumps({
                        'type': 'Message',
                        'content': data['content'],
                    }).encode("utf-8") )

        if data['type'] == "FileTransfer": #文件传输
            targetmessageConn = self.SessionManege.messageConnTable.get(data['targetID'])
            targetmessageConn.send(json.dumps({
                        'type': 'FileTransfer',
                    }).encode("utf-8") )
            fileTransfer = FileTransfer(data['selfID'],data['targetID'],self.SessionManege)
            fileTransfer.start()

        if data['type'] == "videoChat": #视频聊天
            targetmessageConn = self.SessionManege.messageConnTable.get(data['targetID'])
            targetmessageConn.send(json.dumps({
                        'type': 'videoChat',
                    }).encode("utf-8") )
            videoTransfer = VideoTransfer(data['selfID'],data['targetID'],self.SessionManege)

        if data['type'] == "PairTest":
            self.pairTest(data['selfID'],data['targetID'])
            
    def run(self):
        try:
             while True:
                 msg = self.messageConn.recv(1024).decode('utf-8')
                 if not msg:
                     break   
                 else :
                    self.msgHandle(msg)
        except socket.error as e:
            print(e.args)
            pass
        finally:
            targetID = self.SessionManege.pairTable.get(self.selfID)
            targetmessageConn = self.SessionManege.messageConnTable.get(targetID)
            self.SessionManege.close_messageConn(self.selfID)
            targetmessageConn.send(json.dumps({
                        'type': 'pairInterruption',
                        'Info': "对方中断退出会话",
                    }).encode("utf-8"))
            self.messageConn.close()


class FileTransfer(threading.Thread):
    def __init__(self, sendID, receiveID, SessionManege):
        super(FileTransfer, self).__init__()
        self.sendConn = SessionManege.fileConnTable[sendID]
        self.receiveConn = SessionManege.fileConnTable[receiveID]
        self.SessionManege = SessionManege

    def receiveFile(self):
        while True:       
            try:
                fileInfo = self.sendConn.recv(1024)
                self.receiveConn.send(fileInfo)  # 向接收方发文件信息

                fileInfo = fileInfo.decode("utf-8").split("|")
                filename = fileInfo[0]
                file_size = (int)(fileInfo[1])

                # 2.接收文件内容
                self.receiveConn.recv(1024)
                self.sendConn.send("ready".encode("utf-8"))  # 向发送方回复就绪信号
                received_size = 0
                while received_size < file_size:
                    size = 0  

                    if file_size - received_size > 1024: # 每次只接收 1024
                        size = 1024
                    else:  # 最后一次接收
                        size = file_size - received_size

                    data = self.sendConn.recv(size)  #多次接收内容
                    data_len = len(data)
                    received_size += data_len
                    self.receiveConn.send(data)  # 向接收方转发文件

            except socket.error as e:
                print(e.args)
            
    def run(self):
        self.receiveFile()


class VideoTransfer(threading.Thread):
    def __init__(self, sendID, receiveID, SessionManege):
        super(VideoTransfer, self).__init__()

        self.sendConn = SessionManege.videoConnTable[sendID]
        self.receiveConn = SessionManege.videoConnTable[receiveID]
        threading.Thread(target=self.receiveVideo,args=(self.sendConn,self.receiveConn)).start()
        
        self.receiveConn = SessionManege.videoConnTable[sendID]
        self.sendConn = SessionManege.videoConnTable[receiveID]
        threading.Thread(target=self.receiveVideo,args=(self.sendConn,self.receiveConn)).start()

    def receiveVideo(self,sendConn,receiveConn):
        while True:       
            try:
                image = sendConn.recv(1300000)
                receiveConn.sendall(image)
            except socket.error as e:
                print(e.args)
            


if __name__ == '__main__':
    ip_port = "127.0.0.1"
    massage_server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    massage_server.bind((ip_port, 8000))
    massage_server.listen(20)  

 
    file_server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    file_server.bind((ip_port, 8001))
    file_server.listen(20) 

    video_server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    video_server.bind((ip_port, 8002))
    video_server.listen(20) 

    sessionManege = SessionManege()
    print("监听开始..")
    try:
        while True:
            messageConn, addr = massage_server.accept()  # 等待连接
            fileConn, addr = file_server.accept()  # 等待连接
            videoConn, addr = video_server.accept()  # 等待连接
            # 利用handler来管理线程,实现线程之间的socket的相互通信
            sessionManege.newSession(messageConn, fileConn,videoConn)
    except socket.error:
        pass

