#ifndef SEMANT_H_
#define SEMANT_H_

#include <assert.h>
#include <iostream>  
#include <map>
#include <set>
#include <vector>
#include <algorithm>
#include "seal-decl.h"
#include "seal-stmt.h"
#include "seal-expr.h"
#include "stringtab.h"
#include "symtab.h"
#include "list.h"
#include <stack>

#define TRUE 1
#define FALSE 0


// color


#endif

